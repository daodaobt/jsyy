import os
from celery import Celery

# 设置Django默认环境变量
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'gamemall.settings')

# 创建Celery应用实例
app = Celery('gamemall')

# 从Django配置中加载Celery设置
app.config_from_object('django.conf:settings', namespace='CELERY')

# 自动发现所有注册的Django app中的tasks.py
app.autodiscover_tasks()