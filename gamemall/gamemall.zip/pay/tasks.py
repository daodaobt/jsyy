from celery import shared_task
from celery.utils.log import get_task_logger
from django.conf import settings
from django.db import transaction
import requests
import logging
from userapp.models import *


@shared_task(bind=True, max_retries=3)
def process_payment_success(self, order_number):
    try:
        with transaction.atomic():
            order = sinkingorder.objects.select_for_update().get(ordernumber=order_number)
            order.state = True
            order.save(update_fields=['state'])

            # 更新充值记录
            player = order.player
            topup, created = topupinfo.objects.get_or_create(
                player=player,
                defaults={'uptoday': 0, 'uptotal': order.price}
            )
            if not created:
                topup.uptotal = topup.uptotal + order.price
                topup.save(update_fields=['uptotal'])

        # 发送道具请求（独立事务）
        send_item_request.delay(order.id)
        return True
    except Exception as e:
        self.retry(exc=e, countdown=60)


logger = logging.getLogger(__name__)


@shared_task(bind=True, max_retries=3, default_retry_delay=60)
def send_item_request(self, order_id):
    try:
        # 使用独立事务获取订单数据
        with transaction.atomic():
            order = sinkingorder.objects.select_for_update().get(id=order_id)
            commodity = commodityinfo.objects.get(name=order.commodity)

            # 从映射文件获取道具编号
            item_number = settings.ITEM_MAPPINGS.get(commodity.name)
            if not item_number:
                error_msg = f"商品 '{commodity.name}' 未找到对应的道具编号"
                print(error_msg)
                raise ValueError(error_msg)

            # 准备请求参数
            headers = {
                'User-Agent': settings.EXTERNAL_API_USER_AGENT,
                'Cookie': settings.EXTERNAL_API_COOKIE,
                'Referer': settings.EXTERNAL_API_REFERER,
                'X-Requested-With': 'XMLHttpRequest'
            }

            data = {
                'sqm': settings.API_SECRET_KEY,
                'usr': order.player.account,
                'bao': '500001',  # 固定参数
                'num': commodity.num,
                'item': item_number,
                'items': '0',  # 固定参数
                'nums': '',  # 固定参数
                'quid': '1',  # 固定参数
                'gnxz': '2'  # 固定参数
            }

            # 发送请求到外部API
            print(f"开始发送道具请求，订单ID: {order_id}，参数: {data}")
            response = requests.post(
                settings.EXTERNAL_API_URL,
                headers=headers,
                data=data,
                timeout=30  # 设置超时时间
            )
            response.raise_for_status()

            # 检查响应内容
            if '发送成功' not in response.text:
                error_msg = f"外部API返回异常: {response.text}"
                print(error_msg)
                raise requests.exceptions.RequestException(error_msg)

            print(f"道具发放成功，订单ID: {order_id}，响应: {response.text}")
            return True

    except Exception as e:
        print(f"道具发放失败，订单ID: {order_id}，错误: {str(e)}")
        self.retry(exc=e, countdown=60 * self.request.retries)

logger = get_task_logger(__name__)

@shared_task(bind=True)
def example_task(self, x, y):
    try:
        print(f"执行任务 {x} and {y}")
        return x + y
    except Exception as e:
        self.retry(exc=e, countdown=60)