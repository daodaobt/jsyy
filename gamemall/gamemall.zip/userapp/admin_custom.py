from django.contrib.admin import AdminSite

class CustomAdminSite(AdminSite):
    # 自定义逻辑
    pass