from django import forms
from userapp.models import *

class ProductCategoryForm(forms.ModelForm):
    class Meta:
        model = productinfo
        fields = '__all__'

class ProductForm(forms.ModelForm):
    class Meta:
        model = commodityinfo
        fields = '__all__'

class UserForm(forms.ModelForm):
    class Meta:
        model = userinfo
        fields = '__all__'

class CDKForm(forms.ModelForm):
    class Meta:
        model = CDKActivation
        fields = '__all__'